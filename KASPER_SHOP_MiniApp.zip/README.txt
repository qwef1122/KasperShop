KASPER SHOP — Telegram Mini App
=================================

В архиве:
- index.html
- styles.css
- script.js
- assets/banner.png

Контакт продавца:
@Mslig1

Загрузка в Cloudflare:
1. Открой Cloudflare → Workers & Pages → Create application.
2. Выбери "Upload your static files".
3. Загрузите содержимое этого архива.
4. Нажмите Deploy.
5. Полученный HTTPS-адрес можно указать как Main Mini App в @BotFather.

Примечание:
Каталог сделан как витрина категорий без отзывов. Для актуального наличия покупатель переходит в личный чат Telegram.
