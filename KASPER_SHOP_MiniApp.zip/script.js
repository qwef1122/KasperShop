const tg = window.Telegram?.WebApp;
if (tg) {
  tg.ready();
  tg.expand();
  document.documentElement.style.setProperty('--tg-bg', tg.themeParams?.bg_color || '#070711');
}
document.getElementById('tgClose')?.addEventListener('click', () => {
  if (tg) tg.close();
});

const toast = document.getElementById('toast');
document.querySelectorAll('.category-card').forEach(card => {
  card.addEventListener('click', () => {
    toast.textContent = card.dataset.message || 'Напишите мне в Telegram.';
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2200);
  });
});
